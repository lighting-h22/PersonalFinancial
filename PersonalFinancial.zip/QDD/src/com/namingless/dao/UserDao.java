/**
 * 
 */
package com.namingless.dao;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

import org.apache.ibatis.session.SqlSession;

import com.namingless.pojo.Pager;
import com.namingless.pojo.User;

public class UserDao implements DaoUtils<User> {

	public Pager<User> findUser(User user, int pageNum, int pageSize) {

		// ����������ȡ��������
		List<User> users = getList();

		// ���ݲ���������ҳ����
		Pager<User> pager = new Pager<User>(pageNum, pageSize, users);

		return pager;

	}

	@Override
	public User getOne(Integer id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public int delete(Integer id) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int update(User t) {
		// TODO Auto-generated method stub
		return 0;
	}

	// Userȫ��ѯ
	@Override
	public ArrayList<User> getList() {
		List<User> users = new ArrayList<>();
		SqlSession sqlSession = Connector.getSqlSession();

		users = sqlSession.selectList("com.namingless.mapper.UserMapper.findUser");
		sqlSession.close();

		return (ArrayList<User>) users;
	}

	// ��ѯ����
	public int totalUserNum() {
		SqlSession sqlSession = Connector.getSqlSession();

		int num = sqlSession.selectOne("com.namingless.mapper.UserMapper.totalUserNum");
		System.out.println(num);

		return num;
	}

	// �����û�����
	public int update(int u_id, String u_pw, String u_name, double u_budget, int a_id) {
		SqlSession sqlSession = Connector.getSqlSession();

		User user = new User(u_id, u_pw, u_name, u_budget, a_id);
		int result = sqlSession.update("com.namingless.mapper.UserMapper.updateUser", user);
		sqlSession.commit();
		sqlSession.close();

		return result;
	}

	// ɾ���û�
	public int delete(int u_id, int a_id) {
		SqlSession sqlSession = Connector.getSqlSession();

		User user = new User(u_id, a_id);
		int result = sqlSession.delete("com.namingless.mapper.UserMapper.deleteUser", user);
		sqlSession.commit();
		sqlSession.close();
		return result;
	}

	// �����û�
	public int insert(int u_id, String u_pw, String u_name, double u_budget, int a_id) {
		SqlSession sqlSession = Connector.getSqlSession();

		User user = new User(u_id, u_pw, u_name, u_budget, a_id);
		int result = sqlSession.insert("com.namingless.mapper.UserMapper.addUser", user);
		sqlSession.commit();
		sqlSession.close();
		return result;
	}

	// ����id�����û�
	public User getOne(User user) {
		SqlSession sqlSession = Connector.getSqlSession();

		User result = sqlSession.selectOne("com.namingless.mapper.UserMapper.findOneUser", user);
		sqlSession.close();

		return result;
	}

	@Override
	public int insert(User obj) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public User getOne(String sql) {
		// TODO Auto-generated method stub
		return null;
	}

}
