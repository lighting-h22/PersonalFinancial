/**
 * 
 */
package com.namingless.dao;

import java.util.ArrayList;
import java.util.List;

import org.apache.ibatis.session.SqlSession;

import com.namingless.pojo.Assets;
import com.namingless.pojo.Assets;
import com.namingless.pojo.User;



/**
 * ��Ŀ�� QDD
 * ����AssetsDao
 * ������
 * ������Adimitor
 * ����ʱ��2021��4��14��
 */
public abstract class AssetsDao implements DaoUtils<Assets> {

	/**
	 * ��ѯ����
	 */
	@Override
	public List<Assets> getList() {
		SqlSession sqlSession = Connector.getSqlSession();
		List<Assets> list = sqlSession.selectList("com.namingless.mapper.AssetsMapper.findAllAssetss");
		sqlSession.close();
		return list;
	}

	/**
	 * ��ѯһ������Id
	 */
	@Override
	public Assets getOne(Integer id) {
		SqlSession sqlSession = Connector.getSqlSession();
		Assets user = sqlSession.selectOne("com.namingless.mapper.AssetsMapper.findAssetsById",id);
		sqlSession.close();
		return user;
	}

	
	/**
	 * ����һ��
	 */
	@Override
	public int insert(Assets obj) {
		SqlSession sqlSession = Connector.getSqlSession();
		int result = sqlSession.insert("com.namingless.mapper.AssetsMapper.insertOne", obj);
		sqlSession.commit();
		sqlSession.close();
		return result;
	}
	/**
	 * ɾ��
	 */
	@Override
	public int delete(Integer id) {
		SqlSession sqlSession = Connector.getSqlSession();
		int result = sqlSession.insert("com.namingless.mapper.AssetsMapper.delete", id);
		sqlSession.clearCache();
		return result;
	}
	/**
	 * ����
	 */
	@Override
	public int update(Assets assets) {
		SqlSession sqlSession = Connector.getSqlSession();
		int result = sqlSession.insert("com.namingless.mapper.AssetsMapper.update", assets);
		sqlSession.close();
		return result;
	}
	public Assets getOne(String other) {
		// TODO Auto-generated method stub
		return null;
	}
	
}
