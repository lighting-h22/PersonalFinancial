/**
 * 
 */
package com.namingless.dao;

import java.io.IOException;
import java.io.InputStream;

import org.apache.ibatis.io.Resources;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;

/**
 * ��Ŀ�� QDD
 * ����Connector
 * ������
 * ������Adimitor
 * ����ʱ��2021��4��30��
 */
public class Connector {

	static InputStream input;
	static SqlSession sqlSession;
	public static SqlSession getSqlSession() {
		
		String resource = "./com/namingless/mapper/mybatis-config.xml";
		try {
			input = Resources.getResourceAsStream(resource);
			SqlSessionFactory sqlSessionFactory = new SqlSessionFactoryBuilder().build(input);
			sqlSession = sqlSessionFactory.openSession();
			input.close();
			System.out.println("�Ự�ɹ�");
			return sqlSession;
		} catch (IOException e) {
			e.printStackTrace();
		}	
		return null;	
	}
	
	
	/**
	 * 
	 */
	public void colseResources(SqlSession sqlSession) {
		if(sqlSession!=null)
			sqlSession.close();

	}
}
