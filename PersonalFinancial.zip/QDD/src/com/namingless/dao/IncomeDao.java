package com.namingless.dao;

import java.io.IOException;
import java.io.InputStream;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import org.apache.ibatis.io.Resources;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;

import com.namingless.pojo.Income;

public class IncomeDao implements DaoUtils<Income> {

	// ��ȡȫ���˵�
	@Override
	public ArrayList<Income> getList() {
		List<Income> income = new ArrayList<>();
		SqlSession sqlSession = Connector.getSqlSession();
		income = sqlSession.selectList("com.namingless.mapper.IncomeMapper.findIncome");
		sqlSession.close();
		return (ArrayList<Income>) income;
	}

	// ������ݲ�ѯ
	public ArrayList<Income> getIcomeByYear(int year) {
		List<Income> income = new ArrayList<>();

		SqlSession sqlSession = Connector.getSqlSession();
		income = sqlSession.selectList("com.namingless.mapper.IncomeMapper.findOneIncomeByYear", year);
		sqlSession.close();

		return (ArrayList<Income>) income;
	}

	// �������²�ѯ
	public ArrayList<Income> getIcomeByMon(int yearMon) {
		List<Income> income = new ArrayList<>();
		String resource = "mybatis-config.xml";
		InputStream input;

		try {
			input = Resources.getResourceAsStream(resource);
			SqlSessionFactory sqlSessionFactory = new SqlSessionFactoryBuilder().build(input);
			SqlSession sqlSession = sqlSessionFactory.openSession();
			/*
			 * ��ʽ��202005
			 */
			income = sqlSession.selectList("com.namingless.mapper.IncomeMapper.findOneIncomeByMon", yearMon);
			sqlSession.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return (ArrayList<Income>) income;
	}

	// ���������ղ�ѯ
	public ArrayList<Income> getIcomeByDate(int date) {
		List<Income> income = new ArrayList<>();
		SqlSession sqlSession = Connector.getSqlSession();

		income = sqlSession.selectList("com.namingless.mapper.IncomeMapper.findOneIncomeByDate", date);
		System.out.println(income);
		sqlSession.close();

		return (ArrayList<Income>) income;
	}

	// ��������
	public int insert(int i_id, int u_id, LocalDate i_date, double i_addition) {
		SqlSession sqlSession = Connector.getSqlSession();
		Income income = new Income(i_id, u_id, i_date, i_addition);
		int result = sqlSession.insert("com.namingless.mapper.UserMapper.addIncome", income);
		sqlSession.commit();
		sqlSession.close();

		return result;
	}

	// ��������
	public int update(int i_id, int u_id, LocalDate i_date, double i_addition) {
		SqlSession sqlSession = Connector.getSqlSession();
		Income income = new Income(i_id, u_id, i_date, i_addition);
		int result = sqlSession.update("com.namingless.mapper.UserMapper.updateIncome", income);
		sqlSession.commit();
		sqlSession.close();
					
		

		return result;
	}

	// ɾ������
	public int delete(int i_id, int u_id) {
		SqlSession sqlSession = Connector.getSqlSession();

		Income income = new Income(i_id, u_id);
		int result = sqlSession.delete("com.namingless.mapper.UserMapper.deleteIncome", income);
		sqlSession.commit();
		sqlSession.close();
		
		return result;
	}

	@Override
	public Income getOne(Integer id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public int delete(Integer id) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int update(Income income) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public Income getOne(String sql) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public int insert(Income obj) {
		// TODO Auto-generated method stub
		return 0;
	}

}
