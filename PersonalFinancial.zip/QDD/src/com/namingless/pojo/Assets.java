/**
 * 
 */
package com.namingless.pojo;

/**
 * ��Ŀ�� QDD
 * ����Assets
 * ������
 * ������Adimitor
 * ����ʱ��2021��4��14��
 */
public class Assets {
	private int a_id;
	private int u_id;
	private double a_virtual;
	private double a_entity;
	public int getA_id() {
		return a_id;
	}
	public void setA_id(int a_id) {
		this.a_id = a_id;
	}
	public int getU_id() {
		return u_id;
	}
	public void setU_id(int u_id) {
		this.u_id = u_id;
	}
	public double getA_virtual() {
		return a_virtual;
	}
	public void setA_virtual(double a_virtual) {
		this.a_virtual = a_virtual;
	}
	public double getA_entity() {
		return a_entity;
	}
	public void setA_entity(double a_entity) {
		this.a_entity = a_entity;
	}
	public Assets(int a_id, int u_id, double a_virtual, double a_entity) {
		super();
		this.a_id = a_id;
		this.u_id = u_id;
		this.a_virtual = a_virtual;
		this.a_entity = a_entity;
	}
	public Assets() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	@Override
	public String toString() {
		return "Assets [a_id=" + a_id + ", u_id=" + u_id + ", a_virtual=" + a_virtual + ", a_entity=" + a_entity + "]";
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		long temp;
		temp = Double.doubleToLongBits(a_entity);
		result = prime * result + (int) (temp ^ (temp >>> 32));
		result = prime * result + a_id;
		temp = Double.doubleToLongBits(a_virtual);
		result = prime * result + (int) (temp ^ (temp >>> 32));
		result = prime * result + u_id;
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Assets other = (Assets) obj;
		if (Double.doubleToLongBits(a_entity) != Double.doubleToLongBits(other.a_entity))
			return false;
		if (a_id != other.a_id)
			return false;
		if (Double.doubleToLongBits(a_virtual) != Double.doubleToLongBits(other.a_virtual))
			return false;
		if (u_id != other.u_id)
			return false;
		return true;
	}
	
	
}
