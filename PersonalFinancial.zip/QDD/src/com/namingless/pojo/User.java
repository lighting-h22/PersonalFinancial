/**
 * 
 */
package com.namingless.pojo;

import java.util.Collections;

/**
 * ��Ŀ�� QDD
 * ����User
 * ������
 * ������Adimitor
 * ����ʱ��2021��4��14��
 */
public class User implements Comparable<User> {

	public User() {
		super();
		// TODO Auto-generated constructor stub
	}

	public User(int u_id, String u_pw, String u_name, double u_budget, int a_id) {
		super();
		this.u_id = u_id;
		this.u_pw = u_pw;
		this.u_name = u_name;
		this.u_budget = u_budget;
		this.a_id = a_id;
	}

	/**
	 * @param u_id2
	 * @param a_id2
	 */
	

	private int u_id;
	public User(int u_id, int a_id) {
		super();
		this.u_id = u_id;
		this.a_id = a_id;
	}

	private String u_pw;
	private String u_name;
	private double u_budget;
	private int a_id;
	
	@Override
	public String toString() {
		return "User [u_id=" + u_id + ", u_pw=" + u_pw + ", u_name=" + u_name + ", u_budget=" + u_budget + ", a_id="
				+ a_id + "]";
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + a_id;
		long temp;
		temp = Double.doubleToLongBits(u_budget);
		result = prime * result + (int) (temp ^ (temp >>> 32));
		result = prime * result + u_id;
		result = prime * result + ((u_name == null) ? 0 : u_name.hashCode());
		result = prime * result + ((u_pw == null) ? 0 : u_pw.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		User other = (User) obj;
		if (a_id != other.a_id)
			return false;
		if (Double.doubleToLongBits(u_budget) != Double.doubleToLongBits(other.u_budget))
			return false;
		if (u_id != other.u_id)
			return false;
		if (u_name == null) {
			if (other.u_name != null)
				return false;
		} else if (!u_name.equals(other.u_name))
			return false;
		if (u_pw == null) {
			if (other.u_pw != null)
				return false;
		} else if (!u_pw.equals(other.u_pw))
			return false;
		return true;
	}

	public int getU_id() {
		return u_id;
	}

	public void setU_id(int u_id) {
		this.u_id = u_id;
	}

	public String getU_pw() {
		return u_pw;
	}

	public void setU_pw(String u_pw) {
		this.u_pw = u_pw;
	}

	public String getU_name() {
		return u_name;
	}

	public void setU_name(String u_name) {
		this.u_name = u_name;
	}

	public double getU_budget() {
		return u_budget;
	}

	public void setU_budget(double u_budget) {
		this.u_budget = u_budget;
	}

	public int getA_id() {
		return a_id;
	}

	public void setA_id(int a_id) {
		this.a_id = a_id;
	}

	@Override
	public int compareTo(User user) {

		return this.getU_name().compareTo(user.getU_name());
	}
	
	public static void main(String[] args) {
		
	}

}
