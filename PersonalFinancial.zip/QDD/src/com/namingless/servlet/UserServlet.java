package com.namingless.servlet;

import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.namingless.daoImpl.BillDaoImpl;
import com.namingless.pojo.Bill;

/**
 * Servlet implementation class UserServlet
 */
@WebServlet("/userServlet")
public class UserServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	BillDaoImpl billDaoImpl = new BillDaoImpl();
       
    
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String servletPath = request.getServletPath();
		String methodname = servletPath.substring(1,servletPath.length()-3);
		System.out.println(methodname);
			Method method;
			try {
				method = getClass().getDeclaredMethod(methodname, HttpServletRequest.class,HttpServletResponse.class);
				method.invoke(this, request,response);
			} catch (Exception e) {
				
				
			}
		
		
	}

	
	private void query(HttpServletRequest request, HttpServletResponse response) {
		System.out.println("query ");
		
//		billDaoImpl.update(new Bill());
		request.setAttribute("res", "result");
		try {
			request.getRequestDispatcher("/login.jsp").forward(request, response);
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}
	private void update(HttpServletRequest request, HttpServletResponse response) {
		System.out.println("update ");
		
	}
}
