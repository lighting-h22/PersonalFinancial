/**
 * 
 */
package com.namingless.dao;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

import org.apache.ibatis.io.Resources;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;

import com.namingless.pojo.Assets;
import com.namingless.pojo.Bill;
import com.namingless.pojo.Assets;
import com.namingless.pojo.User;





/**
 * ��Ŀ�� QDD
 * ����AssetsDao
 * ������
 * ������Adimitor
 * ����ʱ��2021��4��14��
 */
public abstract class AssetsDao implements DaoUtils<Assets> {

	InputStream input = null;
	List<Bill> list = null;
	SqlSession sqlSession = null;
	String resource = "./com/namingless/mapper/mybatis-config.xml";
	
	
	private SqlSession getSqlSession(){
		SqlSessionFactory sqlSessionFactory =null;
		try {
			input = Resources.getResourceAsStream(resource);
			sqlSessionFactory = new SqlSessionFactoryBuilder().build(input);
			input.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return sqlSessionFactory.openSession();
	}
	/**
	 * ��ѯ����
	 */
	public List<Assets> getList() {
		SqlSession sqlSession = getSqlSession();
		List<Assets> list = sqlSession.selectList("com.namingless.mapper.AssetsMapper.findAllAssetss");
		sqlSession.commit();sqlSession.close();
		return list;
	}

	/**
	 * ��ѯһ������Id
	 */
	public Assets getOne(Integer id) {
		SqlSession sqlSession = getSqlSession();
		Assets user = sqlSession.selectOne("com.namingless.mapper.AssetsMapper.findAssetsById",id);
		sqlSession.commit();
		sqlSession.commit();sqlSession.close();
		
		return user;
	}

	
	/**
	 * ����һ��
	 */
	@Override
	public int insert(Assets obj) {
		SqlSession sqlSession = getSqlSession();
		int result = sqlSession.insert("com.namingless.mapper.AssetsMapper.insertOne", obj);
		sqlSession.commit();
		sqlSession.commit();sqlSession.close();
		return result;
	}
	/**
	 * ɾ��
	 */
	@Override
	public int delete(Integer id) {
		SqlSession sqlSession = getSqlSession();
		int result = sqlSession.insert("com.namingless.mapper.AssetsMapper.delete", id);
		sqlSession.commit();sqlSession.close();
		return result;
	}
	/**
	 * ����
	 */
	@Override
	public int update(Assets assets) {
		SqlSession sqlSession = getSqlSession();
		int result = sqlSession.insert("com.namingless.mapper.AssetsMapper.update", assets);
		sqlSession.commit();sqlSession.close();
		return result;
	}
	public Assets getOne(String other) {
		// TODO Auto-generated method stub
		return null;
	}
	
}
