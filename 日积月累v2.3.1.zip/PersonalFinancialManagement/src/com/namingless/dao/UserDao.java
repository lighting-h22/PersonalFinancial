/**
 * 
 */
package com.namingless.dao;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

import org.apache.ibatis.io.Resources;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;

import com.namingless.pojo.Bill;
import com.namingless.pojo.Pager;
import com.namingless.pojo.User;



public class UserDao implements DaoUtils<User> {

	InputStream input = null;
	List<Bill> list = null;
	SqlSession sqlSession = null;
	String resource = "./com/namingless/mapper/mybatis-config.xml";
	
	private SqlSession getSqlSession(){
		SqlSessionFactory sqlSessionFactory =null;
		try {
			input = Resources.getResourceAsStream(resource);
			sqlSessionFactory = new SqlSessionFactoryBuilder().build(input);
			input.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return sqlSessionFactory.openSession();
	}
	public int findCountOfUser() {
		sqlSession = getSqlSession();
		 int  userCount = sqlSession.selectOne("com.namingless.mapper.UserMapper.findCountOfUser");
		 sqlSession.commit();sqlSession.close();
		return userCount;
		
	}
	public List<User> findByPage(int start, int rows) {
		sqlSession = getSqlSession();
		 List<User> user = sqlSession.selectList("com.namingless.mapper.UserMapper.findUserByName", start);
		 sqlSession.commit();sqlSession.close();
		return user;
	}
	public Pager<User> findUser(User user, int pageNum, int pageSize) {

		// ����������ȡ��������
		List<User> users = getList();

		// ���ݲ���������ҳ����
		Pager<User> pager = new Pager<User>(pageNum, pageSize, users);

		return pager;

	}

	@Override
	public User getOne(Integer id) {
		// TODO Auto-generated method stub
		return null;
	}
	public User findUserByName(String  name) {
		 sqlSession = getSqlSession();
		 User user = sqlSession.selectOne("com.namingless.mapper.UserMapper.findUserByName", name);
		 sqlSession.commit();sqlSession.close();
		return user;
	}
	public User findUserById(int  id) {
		 sqlSession = getSqlSession();
		 User user = sqlSession.selectOne("com.namingless.mapper.UserMapper.findUserById", id);
		 sqlSession.commit();sqlSession.close();
		return user;
	}
	public User findLoginUser(User user) {
		System.out.println(user);
		sqlSession = getSqlSession();
		User user2 = sqlSession.selectOne("com.namingless.mapper.UserMapper.findLoginUser", user);
		
		sqlSession.commit();sqlSession.close();
		return user2;
	}

	@Override
	public int delete(Integer id) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int update(User t) {
		// TODO Auto-generated method stub
		return 0;
	}

	// Userȫ��ѯ
	@Override
	public List<User> getList() {
		List<User> users = new ArrayList<>();
		SqlSession sqlSession = getSqlSession();

		users = sqlSession.selectList("com.namingless.mapper.UserMapper.findUser");
		sqlSession.commit();sqlSession.close();

		return (ArrayList<User>) users;
	}

	// ��ѯ����
	public int totalUserNum() {
		SqlSession sqlSession = getSqlSession();

		int num = sqlSession.selectOne("com.namingless.mapper.UserMapper.totalUserNum");
		System.out.println(num);

		return num;
	}

	// �����û�����
	public int update(int u_id, String u_pw, String u_name, double u_budget, int a_id) {
		SqlSession sqlSession = getSqlSession();

		User user = new User(u_id, u_pw, u_name, u_budget, a_id);
		int result = sqlSession.update("com.namingless.mapper.UserMapper.updateUser", user);
		
		sqlSession.commit();sqlSession.close();

		return result;
	}

	// ɾ���û�
	public int delete(int u_id, int a_id) {
		SqlSession sqlSession = getSqlSession();

		User user = new User(u_id, a_id);
		int result = sqlSession.delete("com.namingless.mapper.UserMapper.deleteUser", user);
		
		sqlSession.commit();sqlSession.close();
		return result;
	}

	// �����û�
	public int addUser(int u_id, String u_pw, String u_name, double u_budget, int a_id) {
		SqlSession sqlSession = getSqlSession();

		User user = new User(u_id, u_pw, u_name, u_budget, a_id);
		int result = sqlSession.insert("com.namingless.mapper.UserMapper.addUser", user);
		
		sqlSession.commit();sqlSession.close();
		return result;
	}
	public int addUser(User user) {
		SqlSession sqlSession = getSqlSession();
		int result = sqlSession.insert("com.namingless.mapper.UserMapper.addUser", user);
		
		sqlSession.commit();sqlSession.close();
		return result;
	}


	// ����id�����û�
	public User getOne(User user) {
		SqlSession sqlSession = getSqlSession();

		User result = sqlSession.selectOne("com.namingless.mapper.UserMapper.findOneUser", user);
		sqlSession.commit();sqlSession.close();

		return result;
	}

	

	@Override
	public User getOne(String sql) {
		// TODO Auto-generated method stub
		return null;
	}
	/* (non-Javadoc)
	 * @see com.namingless.dao.DaoUtils#insert(java.lang.Object)
	 */
	@Override
	public int insert(User user) {
		SqlSession sqlSession = getSqlSession();
		int result = sqlSession.insert("com.namingless.mapper.UserMapper.insert", user);
		
		sqlSession.commit();sqlSession.close();
		return result;
	}

}
