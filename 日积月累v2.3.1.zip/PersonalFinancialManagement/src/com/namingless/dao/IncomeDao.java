package com.namingless.dao;

import java.io.IOException;
import java.io.InputStream;
import java.sql.Date;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.ibatis.io.Resources;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;

import com.namingless.pojo.Bill;
import com.namingless.pojo.Income;
import com.namingless.pojo.Pager;
import com.namingless.pojo.User;



public class IncomeDao implements DaoUtils<Income> {
	
	InputStream input = null;
	List<Bill> list = null;
	SqlSession sqlSession = null;
	String resource = "./com/namingless/mapper/mybatis-config.xml";
	
	private SqlSession getSqlSession(){
		SqlSessionFactory sqlSessionFactory =null;
		try {
			input = Resources.getResourceAsStream(resource);
			sqlSessionFactory = new SqlSessionFactoryBuilder().build(input);
			input.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return sqlSessionFactory.openSession();
	}
	
	public Pager<Income> getIcomeByYear(Income income, int pageNum, int pageSize) {

		// ����������ȡ��������
		List<Income> incomes = getIcomeByYear(income);
		
		// ���ݲ���������ҳ����
		Pager<Income> pager = new Pager<Income>(pageNum, pageSize, incomes);		
		
		return pager;

	}
	
	public Pager<Income> getIcomeByDate(Income income, int pageNum, int pageSize) {

		// ����������ȡ��������
		List<Income> incomes = getIcomeByDate(income);
		
		// ���ݲ���������ҳ����
		Pager<Income> pager = new Pager<Income>(pageNum, pageSize, incomes);		
		
		return pager;

	}
	
	public Pager<Income> getIcomeByMon(Income income, int pageNum, int pageSize) {

		// ����������ȡ��������
		List<Income> incomes = getIcomeByMon(income);
		
		// ���ݲ���������ҳ����
		Pager<Income> pager = new Pager<Income>(pageNum, pageSize, incomes);		
		
		return pager;

	}
	
	// ��ȡȫ���˵�
	@Override
	public ArrayList<Income> getList() {
		List<Income> income = new ArrayList<>();
		SqlSession sqlSession = getSqlSession();
		income = sqlSession.selectList("com.namingless.mapper.IncomeMapper.findIncome");
		sqlSession.commit();sqlSession.commit();sqlSession.close();
		return (ArrayList<Income>) income;
	}

	// ������ݲ�ѯ
	public ArrayList<Income> getIcomeByYear(Income income) {
		List<Income> incomes = new ArrayList<>();
		
		
		SqlSession sqlSession = getSqlSession();
		incomes = sqlSession.selectList("com.namingless.mapper.IncomeMapper.findOneIncomeByYear", income);
		sqlSession.commit();sqlSession.commit();sqlSession.close();

		return (ArrayList<Income>) incomes;
	}

	// �������²�ѯ
	public ArrayList<Income> getIcomeByMon(Income income) {
		List<Income> incomes = new ArrayList<>();
			/*
			 * ��ʽ��202005
			 */
		SqlSession sqlSession = getSqlSession();
			incomes = sqlSession.selectList("com.namingless.mapper.IncomeMapper.findOneIncomeByMon",income);
			sqlSession.commit();sqlSession.commit();sqlSession.close();
			
		return (ArrayList<Income>) incomes;
	}

	// ���������ղ�ѯ
	public ArrayList<Income> getIcomeByDate(Income income) {
		List<Income> incomes = new ArrayList<>();

		SqlSession sqlSession = getSqlSession();
		incomes = sqlSession.selectList("com.namingless.mapper.IncomeMapper.findOneIncomeByDate", income);
		
		sqlSession.commit();sqlSession.close();

		return (ArrayList<Income>) incomes;
	}

	// ��������
	public int insert(int i_id, int u_id, String i_dates, double i_addition) {
		SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd");
		String i_date = simpleDateFormat.format(i_dates);
		Map<String,Object> map = new HashMap();
		map.put("i_id", i_id);
		map.put("u_id", u_id);
		map.put("i_date", i_date);
		map.put("i_addition", i_addition);
		int result = sqlSession.insert("com.namingless.mapper.UserMapper.addIncome", map);
		
		sqlSession.commit();sqlSession.close();

		return result;
	}

	// ��������
	public int update(int i_id, int u_id, String i_dates, double i_addition) {
		SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd");
		String i_date = simpleDateFormat.format(i_dates);
		Map<String,Object> map = new HashMap();
		map.put("i_id", i_id);
		map.put("u_id", u_id);
		map.put("i_date", i_date);
		map.put("i_addition", i_addition);
		int result = sqlSession.update("com.namingless.mapper.UserMapper.updateIncome", map);
		sqlSession.commit();sqlSession.close();
					
		

		return result;
	}

	// ɾ������
	public int delete(int i_id, int u_id) {
		Income income = new Income(i_id, u_id);
		int result = sqlSession.delete("com.namingless.mapper.UserMapper.deleteIncome", income);
		
		sqlSession.commit();sqlSession.close();
		
		return result;
	}

	@Override
	public Income getOne(Integer id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public int delete(Integer id) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int update(Income income) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public Income getOne(String sql) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public int insert(Income obj) {
		SqlSessionFactory sqlSessionFactory =null;
		try {
			input = Resources.getResourceAsStream(resource);
			sqlSessionFactory = new SqlSessionFactoryBuilder().build(input);
			input.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		SqlSession openSession = sqlSessionFactory.openSession();
		int result = openSession.insert("com.namingless.mapper.IncomeMapper.insert", obj);
		openSession.commit();
		openSession.close();
		return result;
	}

}
