/**
 * 
 */
package com.namingless.dao;


import java.io.IOException;
import java.io.InputStream;
import java.util.List;
import java.util.Map;

import javax.swing.table.TableStringConverter;

import org.apache.ibatis.io.Resources;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;

import com.namingless.pojo.Bill;
import com.namingless.pojo.BillConditions;
import com.namingless.pojo.User;




/**
 * ��Ŀ�� QDD
 * ����BillDao
 * ������
 * ������Adimitor
 * ����ʱ��2021��4��14��
 */
public abstract class BillDao implements DaoUtils<Bill>{
	/**
	 * �鿴������Mapper.xml�����������Ϣ
	 */
	InputStream input = null;
	List<Bill> list = null;
	SqlSession sqlSession = null;
	String resource = "./com/namingless/mapper/mybatis-config.xml";
	
	
	private SqlSession getSqlSession(){
		SqlSessionFactory sqlSessionFactory =null;
		try {
			input = Resources.getResourceAsStream(resource);
			sqlSessionFactory = new SqlSessionFactoryBuilder().build(input);
			input.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return sqlSessionFactory.openSession();
	}
	@Override
	public List<Bill> getList() {
		
			sqlSession = getSqlSession();
			list = sqlSession.selectList("com.namingless.mapper.BillMapper.findAllBills");
		   
			try {
				sqlSession.commit();sqlSession.close();
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		
		
		
		
		return list;
	}
	public List<Bill> findBillsByConditionOfPrice(BillConditions condition) {
		
		sqlSession = getSqlSession();
		list = sqlSession.selectList("com.namingless.mapper.BillMapper.findBillsByConditionOfPrice",condition);
		try {
			sqlSession.commit();sqlSession.close();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	
	
	
	
	return list;
}
public List<Bill> findBillsByConditionOfDatetime(BillConditions condition) {
		
		sqlSession = getSqlSession();
		list = sqlSession.selectList("com.namingless.mapper.BillMapper.findBillsByConditionOfDatetime",condition);
		try {
			sqlSession.commit();sqlSession.close();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	
	
	
	
	return list;
}
	
	/**
	 * �鿴������Mapper.xml�����10����Ϣ
	 */
//	public List<Bill> getPageOfList(Map<Integer, User> map) throws IOException {
//		
//		sqlSession = getSqlSession();
//		list = sqlSession.selectList("com.namingless.mapper.BillMapper.findPageOfBills",map);
//	
//		try {
//			sqlSession.commit();sqlSession.close();
//			
//		}catch (Exception e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
//		
//		return list;
//	}
	public List<Bill> getPageOfList(Integer from) throws IOException {
		
		sqlSession = getSqlSession();
		list = sqlSession.selectList("com.namingless.mapper.BillMapper.findPageOfBills",from);
	
		try {
			sqlSession.commit();sqlSession.close();
			
		}catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return list;
	}
	/**
	 * ���룬����Mapper.xml������Bill�ı��
	 */
	@Override
	public Bill getOne(Integer id) {
		Bill bill = null;
		
		sqlSession = getSqlSession();
		bill = sqlSession.selectOne("com.namingless.mapper.BillMapper.findBillById",id);
	
		try {
			sqlSession.commit();sqlSession.close();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		
		return bill;
	}

	/**
	 * ���룬����Mapper.xml�������˵�
	 */
	@Override
	public Bill getOne(String other) {
		Bill bill = null;
		
		sqlSession = getSqlSession();
		bill = sqlSession.selectOne("com.namingless.mapper.BillMapper.findBillByName",other);
	
		try {
			sqlSession.commit();sqlSession.close();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	
		
		return bill;
	}

	/**
	 * ���룬����Mapper.xml������Bill
	 */
	@Override
	public int insert(Bill obj) {
		int result = 0;
		sqlSession = getSqlSession();
		 result = sqlSession.insert("com.namingless.mapper.BillMapper.insertOne", obj);
	
		try {
			sqlSession.commit();sqlSession.close();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return result;
	}
	
	
	/**
	 * ɾ��������Mapper.xml������ID
	 */
	
	@Override
	public int delete(Integer id) {
		int result = 0;
		
			sqlSession = getSqlSession();
			 result = sqlSession.insert("com.namingless.mapper.BillMapper.delete", id);
		
		
			try {
				sqlSession.commit();sqlSession.close();
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		
		
		return result;
	}
	/**
	 * ���£�����Mapper.xml������Billʵ��
	 */
	@Override
	public int update(Bill bill) {
		int result = 0;
		
			sqlSession = getSqlSession();
			 result = sqlSession.insert("com.namingless.mapper.BillMapper.update", bill);
		
			try{sqlSession.commit();sqlSession.close();}catch(Exception e){e.printStackTrace();}
		
		
		return result;
	}
	/**
	 * ��ѯ������Mapper.xml������year-2018
	 */

	public List<Bill> getBillsByYear(String year) {
		SqlSession sqlSession = getSqlSession();
		List<Bill> list = sqlSession.selectList("com.namingless.mapper.BillMapper.findBillsByYear",year);
		sqlSession.commit();sqlSession.close();
		return list;
		
	}
	/**
	 * ��ѯ������Mapper.xml������year-month 2018-6
	 */
	public List<Bill> getBillsByMonth(TableStringConverter year_month) {
		SqlSession sqlSession = getSqlSession();
		List<Bill> list = sqlSession.selectList("com.namingless.mapper.BillMapper.findBillsByMonth",year_month);
		sqlSession.commit();sqlSession.close();
		return list;
	}
	/**
	 * ��ѯ������Mapper.xml������year-month-day 2018-6-5
	 */
	public List<Bill> getBillsByDay(String year_month_day) {
		SqlSession sqlSession = getSqlSession();
		List<Bill> list = sqlSession.selectList("com.namingless.mapper.BillMapper.findBillsByDay",year_month_day);
		sqlSession.commit();sqlSession.close();
		return list;
	}

	
}
