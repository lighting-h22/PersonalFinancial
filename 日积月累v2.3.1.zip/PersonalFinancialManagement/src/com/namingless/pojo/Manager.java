/**
 * 
 */
package com.namingless.pojo;

/**
 * ��Ŀ�� QDD
 * ����Manager
 * ������
 * ������Adimitor
 * ����ʱ��2021��4��14��
 */
public class Manager {

	private int m_id;
	private String m_pw;
	private String m_name;
	public Manager() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Manager(int m_id, String m_pw, String m_name) {
		super();
		this.m_id = m_id;
		this.m_pw = m_pw;
		this.m_name = m_name;
	}
	@Override
	public String toString() {
		return "Manager [m_id=" + m_id + ", m_pw=" + m_pw + ", m_name=" + m_name + "]";
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + m_id;
		result = prime * result + ((m_name == null) ? 0 : m_name.hashCode());
		result = prime * result + ((m_pw == null) ? 0 : m_pw.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Manager other = (Manager) obj;
		if (m_id != other.m_id)
			return false;
		if (m_name == null) {
			if (other.m_name != null)
				return false;
		} else if (!m_name.equals(other.m_name))
			return false;
		if (m_pw == null) {
			if (other.m_pw != null)
				return false;
		} else if (!m_pw.equals(other.m_pw))
			return false;
		return true;
	}
	public int getM_id() {
		return m_id;
	}
	public void setM_id(int m_id) {
		this.m_id = m_id;
	}
	public String getM_pw() {
		return m_pw;
	}
	public void setM_pw(String m_pw) {
		this.m_pw = m_pw;
	}
	public String getM_name() {
		return m_name;
	}
	public void setM_name(String m_name) {
		this.m_name = m_name;
	}
	
}
