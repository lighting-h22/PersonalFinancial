/**
 * 
 */
package com.namingless.pojo;

import java.time.LocalDateTime;
import java.time.ZoneOffset;


/**
 * ��Ŀ�� QDD
 * ����Bill
 * ������
 * ������Adimitor
 * ����ʱ��2021��4��14��
 */
public class Bill implements Comparable<Bill>{

	private int b_id;
	private int u_id;
	private LocalDateTime b_datetime;
	private String b_type;
	private double b_price;
	private String b_note;
	public int getB_id() {
		return b_id;
	}
	public void setB_id(int b_id) {
		this.b_id = b_id;
	}
	public int getU_id() {
		return u_id;
	}
	public void setU_id(int u_id) {
		this.u_id = u_id;
	}
	public LocalDateTime getB_datetime() {
		return b_datetime;
	}
	public void setB_datetime(LocalDateTime b_datetime) {
		this.b_datetime = b_datetime;
	}
	public String getB_type() {
		return b_type;
	}
	public void setB_type(String b_type) {
		this.b_type = b_type;
	}
	public double getB_price() {
		return b_price;
	}
	public void setB_price(double b_price) {
		this.b_price = b_price;
	}
	public String getB_note() {
		return b_note;
	}
	public void setB_note(String b_note) {
		this.b_note = b_note;
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((b_datetime == null) ? 0 : b_datetime.hashCode());
		result = prime * result + b_id;
		result = prime * result + ((b_note == null) ? 0 : b_note.hashCode());
		long temp;
		temp = Double.doubleToLongBits(b_price);
		result = prime * result + (int) (temp ^ (temp >>> 32));
		result = prime * result + ((b_type == null) ? 0 : b_type.hashCode());
		result = prime * result + u_id;
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Bill other = (Bill) obj;
		if (b_datetime == null) {
			if (other.b_datetime != null)
				return false;
		} else if (!b_datetime.equals(other.b_datetime))
			return false;
		if (b_id != other.b_id)
			return false;
		if (b_note == null) {
			if (other.b_note != null)
				return false;
		} else if (!b_note.equals(other.b_note))
			return false;
		if (Double.doubleToLongBits(b_price) != Double.doubleToLongBits(other.b_price))
			return false;
		if (b_type == null) {
			if (other.b_type != null)
				return false;
		} else if (!b_type.equals(other.b_type))
			return false;
		if (u_id != other.u_id)
			return false;
		return true;
	}
	@Override
	public String toString() {
		return "Bill [b_id=" + b_id + ", u_id=" + u_id + ", b_datetime=" + b_datetime + ", b_type=" + b_type
				+ ", b_price=" + b_price + ", b_note=" + b_note + "]";
	}
	public Bill(int b_id, int u_id, LocalDateTime b_datetime, String b_type, double b_price, String b_note) {
		super();
		this.b_id = b_id;
		this.u_id = u_id;
		this.b_datetime = b_datetime;
		this.b_type = b_type;
		this.b_price = b_price;
		this.b_note = b_note;
	}
	public Bill(int u_id, LocalDateTime b_datetime, String b_type, double b_price, String b_note) {
		super();
		this.u_id = u_id;
		this.b_datetime = b_datetime;
		this.b_type = b_type;
		this.b_price = b_price;
		this.b_note = b_note;
	}
	public Bill() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	@Override
	public int compareTo(Bill bill) {
		long myDateTime = this.getB_datetime().now().toEpochSecond(ZoneOffset.of("+8"));
		long otherDateTime = bill.getB_datetime().now().toEpochSecond(ZoneOffset.of("+8"));
		
		if(myDateTime>otherDateTime) {
			
			return 1;
		}
		else if (myDateTime<otherDateTime) {
			
			return -1;
		}
		else {
			if(this.getB_type().equals(bill.getB_type())) {
				return Double.compare(this.getB_price(), bill.getB_price());
			}
			return this.getB_type().compareTo(bill.getB_type());
		}
		
	}
	
	
}
