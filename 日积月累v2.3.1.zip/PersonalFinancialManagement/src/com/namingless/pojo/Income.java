/**
 * 
 */
package com.namingless.pojo;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.Comparator;

/**
 * ��Ŀ�� QDD
 * ����Income
 * ������
 * ������Adimitor
 * ����ʱ��2021��4��14��
 */
public class Income implements Comparable<Income> {
	private int i_id;
	private int u_id;
	private String i_date;
	private double i_addition;
	public int getI_id() {
		return i_id;
	}
	public void setI_id(int i_id) {
		this.i_id = i_id;
	}
	public int getU_id() {
		return u_id;
	}
	public void setU_id(int u_id) {
		this.u_id = u_id;
	}
	public String getI_date() {
		return i_date;
	}
	public void setI_date(String i_date) {
		this.i_date = i_date;
	}
	public double getI_addition() {
		return i_addition;
	}
	public void setI_addition(double i_addition) {
		this.i_addition = i_addition;
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		long temp;
		temp = Double.doubleToLongBits(i_addition);
		result = prime * result + (int) (temp ^ (temp >>> 32));
		result = prime * result + ((i_date == null) ? 0 : i_date.hashCode());
		result = prime * result + i_id;
		result = prime * result + u_id;
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Income other = (Income) obj;
		if (Double.doubleToLongBits(i_addition) != Double.doubleToLongBits(other.i_addition))
			return false;
		if (i_date == null) {
			if (other.i_date != null)
				return false;
		} else if (!i_date.equals(other.i_date))
			return false;
		if (i_id != other.i_id)
			return false;
		if (u_id != other.u_id)
			return false;
		return true;
	}
	@Override
	public String toString() {
		return "Income [i_id=" + i_id + ", u_id=" + u_id + ", i_date=" + i_date + ", i_addition=" + i_addition + "]";
	}
	public Income(int i_id, int u_id, String i_date, double i_addition) {
		super();
		this.i_id = i_id;
		this.u_id = u_id;
		this.i_date = i_date;
		this.i_addition = i_addition;
	}
	public Income() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
	/**
	 * @param i_id2
	 * @param u_id2
	 */
	
	public Income(int i_id, int u_id) {
		super();
		this.i_id = i_id;
		this.u_id = u_id;
	}
	/**
	 * @param i_id2
	 * @param u_id2
	 * @param date
	 * @param price
	 */
	
	@Override
	public int compareTo(Income o) {
		// TODO Auto-generated method stub
		return 0;
	}
	

}
