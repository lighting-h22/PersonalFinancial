package com.namingless.servlet;

import java.io.IOException;
import java.time.LocalDateTime;
import java.time.Month;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.namingless.daoImpl.AssetsDaoImpl;
import com.namingless.daoImpl.BillDaoImpl;
import com.namingless.daoImpl.UserDaoImpl;
import com.namingless.pojo.Assets;
import com.namingless.pojo.User;

import utils.DaoImplUtil;

/**
 * Servlet implementation class GetBudget
 */
@WebServlet("/getBudget")
public class GetBudget extends HttpServlet {
	private static final long serialVersionUID = 1L;
	AssetsDaoImpl assetsDaoImpl = (AssetsDaoImpl) DaoImplUtil.getDao(AssetsDaoImpl.class);  
	BillDaoImpl billDaoImpl = (BillDaoImpl) DaoImplUtil.getDao(BillDaoImpl.class);  
	 
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		HttpSession session = request.getSession();
		User user = (User) session.getAttribute("loginUser");
		if (user!=null) {
			Assets assets = assetsDaoImpl.getOne(user.getU_id());
			int monthValue = LocalDateTime.now().getMonthValue();
			double totalOfMonth = billDaoImpl.getTotalOfMonth(user.getU_id());
			System.out.println("*******************"
					+this.getServletName()+ "**********************");
			System.out.println(user);
			System.out.println(monthValue+":"+totalOfMonth);
			System.out.println(assets);
			request.setAttribute("assets", assets);
			request.setAttribute("budget", user.getU_budget());
			request.setAttribute("totalOfMonth", totalOfMonth);
			request.getRequestDispatcher("/budget.jsp?totalOfMonth="+totalOfMonth).forward(request, response);
		}
		else {
			request.getRequestDispatcher("/login.jsp").forward(request, response);
		}
	}

}
