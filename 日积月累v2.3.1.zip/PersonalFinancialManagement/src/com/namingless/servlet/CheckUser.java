package com.namingless.servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.namingless.daoImpl.IncomeDaoImpl;
import com.namingless.daoImpl.UserDaoImpl;

import utils.DaoImplUtil;


@WebServlet("/CheckUser")
public class CheckUser  extends HttpServlet{
	 UserDaoImpl userDaoImpl=(UserDaoImpl) DaoImplUtil.getDao(UserDaoImpl.class);
	
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
		  resp.setContentType("utf-8");
	      String username=req.getParameter("username");
	      try {
			if(userDaoImpl.getOne(username)!=null){
			   System.out.println("���û� ����");		
			   resp.getWriter().print(false);
			}else{
				System.out.println("�û�������ʹ��");
				resp.getWriter().print(true);
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	
	}
}
