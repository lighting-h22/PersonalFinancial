package com.namingless.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.namingless.daoImpl.UserDaoImpl;
import com.namingless.pojo.User;

import utils.DaoImplUtil;


@WebServlet("/UserLogin")
public class UserLogin extends HttpServlet {
	UserDaoImpl userDaoImpl = (UserDaoImpl) DaoImplUtil.getDao(UserDaoImpl.class);
	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		request.getSession().setMaxInactiveInterval(30*60);
		String username = request.getParameter("username");
		String password = request.getParameter("password");
		String rowid = request.getParameter("roletype");
		
		switch (rowid) {
			case "1":
				//����Ա��¼
				break;
	
			case "2":
				//�û���¼
				User user = new User();
				user.setU_name(username);
				user.setU_pw(password);
				User findLoginUser = userDaoImpl.findLoginUser(user);
				System.out.println("findLoginUser��" + findLoginUser);
				if(findLoginUser!=null) {
					HttpSession session = request.getSession();
					session.setAttribute("loginUser", findLoginUser);
					request.getRequestDispatcher("/index.jsp").forward(request, response);
				}
				else {
					response.getWriter().write("<b>���и��û���</b>");
				}
				break;

			default:
				break;
			}
	}

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
	         doPost(req, resp);
	}
}
