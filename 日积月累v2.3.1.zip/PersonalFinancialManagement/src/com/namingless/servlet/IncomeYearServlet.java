package com.namingless.servlet;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.namingless.pojo.Income;
import com.namingless.pojo.Pager;
import com.namingless.pojo.User;
import com.namingless.services.IncomeServiceImpl;

import utils.Constant;

/**
 * Servlet implementation class IncomeMonServlet
 */
@WebServlet("/IncomeYearServlet")
public class IncomeYearServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
      
	private IncomeServiceImpl incomeService = new IncomeServiceImpl();
	public void destroy() {
		super.destroy();
	}
    /**
     * @see HttpServlet#HttpServlet()
     */
    public IncomeYearServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		//���ñ����ʽ
		request.setCharacterEncoding("utf-8");
		/*
		 * ����request����
		 */
		String u_idStr = request.getParameter("u_id");
		User user =(User) request.getSession().getAttribute("loginUser");
		int u_id = user.getU_id();
		
		String i_date= request.getParameter("i_date_year");

		System.out.println(i_date);
		//��ʾ�ڼ�ҳ����
		int pageNum = Constant.DEFAULT_PAGE_NUM;
		String pageNumStr = request.getParameter("pageNum");
		if(pageNumStr != null && !"".equals(pageNumStr.trim())) {
			pageNum = Integer.parseInt(pageNumStr);
			}
		
		//ÿҳ��ʾ��������¼
		int pageSize = Constant.DEFAULT_PAGE_SIZE;
		String pageSizeStr = request.getParameter("pageSize");
		if(pageSizeStr != null && !"".equals(pageSizeStr.trim())) {
			pageSize = Integer.parseInt(pageSizeStr);
			}
		
		
		
		//��װ��ѯ����
		Income income = new Income();
		income.setU_id(u_id);
		income.setI_date(i_date);
		System.out.println(income);
		
		//����service��ȡ���
		Pager<Income> result = incomeService.getIcomeByYear(income, pageNum, pageSize);
		
		//���ؽ��ҳ��
		request.setAttribute("result", result);
		List<Income> a = result.getDataList();
		System.out.println(a.size());
		if(a!=null) {
		for(int i = 0;i<a.size();i++) {
			request.setAttribute("a"+i, a.get(i).getI_addition());
		}
		}
		
		if(a!=null) {
				for(Income i:a) {
					System.out.println(i);
				}
		}
		request.getRequestDispatcher("year.jsp").forward(request,response);
	}
}
