package com.namingless.servlet;

import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.eclipse.jdt.internal.compiler.ast.ThisReference;

import com.namingless.daoImpl.BillDaoImpl;
import com.namingless.daoImpl.IncomeDaoImpl;
import com.namingless.pojo.Bill;
import com.namingless.pojo.BillConditions;
import com.namingless.pojo.Income;
import com.namingless.pojo.User;

import utils.DaoImplUtil;

/**
 * Servlet implementation class UserServlet
 */

public class UserServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	BillDaoImpl billDaoImpl = (BillDaoImpl) DaoImplUtil.getDao(BillDaoImpl.class);
	IncomeDaoImpl incomeDaoImpl = (IncomeDaoImpl) DaoImplUtil.getDao(IncomeDaoImpl.class);
	private Integer attribute;
    
    
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
		
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.getSession().setAttribute("u_id", 1);
		String servletPath = request.getServletPath();
//		String methodname = servletPath.substring(servletPath.indexOf("/")+1,servletPath.indexOf("."));
		String methodname = servletPath.substring(servletPath.indexOf("/")+1,servletPath.indexOf("."));
		System.out.println(this.getClass()+"�����÷�����"+methodname);
			Method method;
			try {
				method = getClass().getDeclaredMethod(methodname, HttpServletRequest.class,HttpServletResponse.class);
				
				method.invoke(this, request,response);
				System.out.println("���䷽���ѵ���");
			} catch (Exception e) {
				e.printStackTrace();
			}
		
		
	}

	private void findBillByPage(HttpServletRequest request, HttpServletResponse response) {
		System.out.println("findBillByPage");
		Integer page = Integer.parseInt(request.getParameter("page"));
		System.out.println("ҳ����"+page);
		List<Bill> list=null;
		HttpSession session = request.getSession();
		User  user = (User) session.getAttribute("loginUser");
		System.out.println("Login-->Index"+user);
		if(user==null) {
			try {
				request.getRequestDispatcher("login.jsp").forward(request, response);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}else {
			
			try {
				list = billDaoImpl.getPageOfList(page*8);
				request.setAttribute("list", list);
				
				System.out.println("���ݴ������");
			} catch (IOException e1) {
				
				e1.printStackTrace();
			}finally {
				
				try {
					request.getRequestDispatcher("/index.jsp").forward(request, response);
				} catch (ServletException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				request.setAttribute("currentPage", page);
				
			}
		}
		
	}
	
	private void query(HttpServletRequest request, HttpServletResponse response) {
		System.out.println("query ");
		
//		billDaoImpl.update(new Bill());
		request.setAttribute("res", "result");
		try {
			request.getRequestDispatcher("/login.jsp").forward(request, response);
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}
	
	
	private void findMyBills(HttpServletRequest request, HttpServletResponse response) {
		System.out.println("findMyBills");
		BillConditions billConditions = new BillConditions(request.getParameter("billType"), request.getParameter("billRank"), request.getParameter("billDatetime"), request.getParameter("outcomeType"));
		System.out.println(billConditions);
		List<Bill> list = null;
		if(billConditions.getBillRank()>=0 &&billConditions.getBillDatetime()<=0) {
			
			list= billDaoImpl.findBillsByConditionOfPrice(billConditions);
		}else {
			list= billDaoImpl.findBillsByConditionOfDatetime(billConditions);
		}
		
		
		request.setAttribute("outcomeBills", list);
		try {
			request.getRequestDispatcher("/finding.jsp").forward(request, response);
		} catch (ServletException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
	}
	private void findMyBillsByCondition(HttpServletRequest request, HttpServletResponse response) {
		System.out.println("findMyBills");
		BillConditions billConditions = new BillConditions(request.getParameter("billType"), request.getParameter("billRank"), request.getParameter("billDatetime"), request.getParameter("outcomeType"));
		System.out.println(billConditions);
		attribute = Integer.parseInt((String) request.getSession().getAttribute("u_id"));
		List<Bill> list = billDaoImpl.findBillsByPriceAsc(attribute);
		sortBillList(list, billConditions);
		
		request.setAttribute("outcomeBills", list);
		try {
			request.getRequestDispatcher("/finding.jsp").forward(request, response);
		} catch (ServletException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
	}
	/**
	 * 
	 */
	private void  sortBillList(List<Bill> list, BillConditions conditions) {
		
		Collections.sort(list);
			
		if (conditions.getBillRank()==-1) {
			Collections.reverse(list);
		}
		
		
	}
	
	
	
	private void showBills(HttpServletRequest request, HttpServletResponse response) {
		List<Bill> list = billDaoImpl.getList();
		request.setAttribute("list", list);
		request.setAttribute("page", 6);
		try {
			request.getRequestDispatcher("/index.jsp").forward(request, response);
		} catch (ServletException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
}
