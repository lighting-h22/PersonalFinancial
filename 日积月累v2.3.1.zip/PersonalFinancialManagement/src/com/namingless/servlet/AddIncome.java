package com.namingless.servlet;

import java.io.IOException;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.namingless.daoImpl.IncomeDaoImpl;
import com.namingless.pojo.Bill;
import com.namingless.pojo.Income;
import com.namingless.pojo.User;

import utils.DaoImplUtil;

/**
 * Servlet implementation class AddIncome
 */
@WebServlet("/addIncome")
public class AddIncome extends HttpServlet {
	private static final long serialVersionUID = 1L;
	IncomeDaoImpl incomeDaoImpl = (IncomeDaoImpl) DaoImplUtil.getDao(IncomeDaoImpl.class);   
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		try {
			System.out.println("*************************"+getServletName()+"***************************");
			HttpSession session = request.getSession();
			User user = (User) session.getAttribute("loginUser");
			String year = request.getParameter("year");
			String month = request.getParameter("month");
			String day = request.getParameter("day");
			double price = Double.parseDouble(request.getParameter("price"));
			
			if(user!=null) {
				LocalDate date = LocalDate.of(Integer.parseInt(year), Integer.parseInt(month), Integer.parseInt(day));
				Income income = new Income(0, user.getU_id(), year+"-"+month+"-"+day, price);
				System.out.println(income);
				int result = incomeDaoImpl.insert(income);
				System.out.println(result);
				if(result==1) {
					request.getRequestDispatcher("shouru.jsp").forward(request, response);
					System.out.println(this.getServletName()+"�������ӳɹ�");
				}
				else {
					System.out.println("������Ϊ��"+result);
					response.getWriter().write("<b>����ʧ��</b>");
				}
				
			}else {
				System.out.println(this.getServletName()+"���û�");
				response.getWriter().write("<b>�Ҳ�����¼�û�</b>");
			}
		} catch (NumberFormatException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

}
