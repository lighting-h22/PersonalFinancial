package com.namingless.servlet;

import java.io.IOException;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.namingless.dao.DaoUtils;
import com.namingless.daoImpl.BillDaoImpl;
import com.namingless.daoImpl.IncomeDaoImpl;
import com.namingless.pojo.Bill;
import com.namingless.pojo.User;

import utils.DaoImplUtil;

/**
 * Servlet implementation class AddBill
 */
@WebServlet("/addBill")
public class AddBill extends HttpServlet {
	private static final long serialVersionUID = 1L;
	BillDaoImpl billDaoImpl = (BillDaoImpl) DaoImplUtil.getDao(BillDaoImpl.class);
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		try {
			HttpSession session = request.getSession();
			//��ȡ���ݲ���
			User user = (User) session.getAttribute("loginUser");
			String year = request.getParameter("year");
			String month = request.getParameter("month");
			String day = request.getParameter("day");			
			double price = Double.parseDouble(request.getParameter("price"));			
			String note = request.getParameter("note");
			String consumerType = request.getParameter("consumerType");
			if(user!=null) {
				LocalDate date = LocalDate.of(Integer.parseInt(year), Integer.parseInt(month), Integer.parseInt(day));
				LocalTime time = LocalTime.now();
				LocalDateTime now = LocalDateTime.of(date, time);
				Bill bill = new Bill(user.getU_id(), now, consumerType, price, note);
				System.out.println(bill);
				int result = billDaoImpl.insert(bill);
				System.out.println(result);
				if(result==1) {
					request.getRequestDispatcher("zhichu.jsp").forward(request, response);
					System.out.println(this.getServletName()+"�˵����ӳɹ�");
				}
				else {
					System.out.println("������Ϊ��"+result);
					response.getWriter().write("<b>����ʧ��</b>");
				}
				
			}else {
				System.out.println(this.getServletName()+"���û�");
				response.getWriter().write("<b>�Ҳ�����¼�û�</b>");
			}
		} catch (NumberFormatException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

}
