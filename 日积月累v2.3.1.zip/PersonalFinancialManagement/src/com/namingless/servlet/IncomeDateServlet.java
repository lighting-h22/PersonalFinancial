package com.namingless.servlet;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.namingless.pojo.Income;
import com.namingless.pojo.Pager;
import com.namingless.pojo.User;
import com.namingless.services.IncomeServiceImpl;

import utils.Constant;




/**
 * Servlet implementation class IncomeServlet4
 */
@WebServlet("/IncomeDateServlet")
public class IncomeDateServlet extends HttpServlet {
private static final long serialVersionUID = 1L;
       
private IncomeServiceImpl incomeService = new IncomeServiceImpl();
public IncomeDateServlet() {
	super();
}
public void destroy() {
	super.destroy();
}
    
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		//���ñ����ʽ
				request.setCharacterEncoding("utf-8");
				/*
				 * ����request����
				 */
				
				//��ȡ�û���¼��u_id
				String u_idStr = request.getParameter("u_id");
				User user =(User) request.getSession().getAttribute("loginUser");
				int u_id = user.getU_id();
				String i_date_year= request.getParameter("i_date_year");
				String i_date_mon= request.getParameter("i_date_mon");
				String i_dates= request.getParameter("i_date");
				String i_date = i_date_year + i_date_mon + i_dates;
				System.out.println(i_date);

				//��ʾ�ڼ�ҳ����
				int pageNum = Constant.DEFAULT_PAGE_NUM;
				String pageNumStr = request.getParameter("pageNum");
				if(pageNumStr != null && !"".equals(pageNumStr.trim())) {
					pageNum = Integer.parseInt(pageNumStr);
					}
				
				//ÿҳ��ʾ��������¼
				int pageSize = Constant.DEFAULT_PAGE_SIZE;
				String pageSizeStr = request.getParameter("pageSize");
				if(pageSizeStr != null && !"".equals(pageSizeStr.trim())) {
					pageSize = Integer.parseInt(pageSizeStr);
					}

				
				
				//��װ��ѯ����
				Income income = new Income();

				income.setI_date(i_date);
				income.setU_id(u_id);
				System.out.println(income);
				
				//����service��ȡ���
				Pager<Income> result = incomeService.getIcomeByDate(income, pageNum, pageSize);
				List<Income> list = result.getDataList();
				if(list!=null) {
					
					for(int i = 0;i<list.size();i++) {
						System.out.println(list.get(i).getI_addition());
						request.setAttribute("c"+i, list.get(i).getI_addition());
					}
				}
				
				//���ؽ��ҳ��
				request.setAttribute("result", result);
				System.out.println(this.getServletName()+"***************************");
				request.getRequestDispatcher("day.jsp").forward(request,response);
	}
	
}
