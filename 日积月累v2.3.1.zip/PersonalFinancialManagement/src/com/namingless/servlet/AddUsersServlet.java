package com.namingless.servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.namingless.dao.DaoUtils;
import com.namingless.daoImpl.IncomeDaoImpl;
import com.namingless.daoImpl.UserDaoImpl;
import com.namingless.pojo.User;

import utils.DaoImplUtil;










@WebServlet("/AddUsersServlet")
public class AddUsersServlet extends HttpServlet {
	UserDaoImpl userDaoImpl = (UserDaoImpl) DaoImplUtil.getDao(UserDaoImpl.class);
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
		doPost(req, resp);

	}
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
		req.setCharacterEncoding("utf-8");
		resp.setContentType("text/html;charset=utf-8");
		
		String name=req.getParameter("username");
		String pwd=req.getParameter("password");
		
		
		
		User user = new User();
		user.setU_name(name);
		user.setU_pw(pwd);
		

		int r;
		try {
			r = userDaoImpl.addUser(user);
			if (r > 0) {
				System.out.println("ע��ɹ�");
			
				req.setAttribute("ok", "ע��ɹ������¼");
				//���ע��ɹ�����תҳ��
				resp.sendRedirect(req.getContextPath() + "/login.jsp");
			} else {
				System.out.println("ע��ʧ��");
			
				req.setAttribute("ok", "ע��ʧ�ܣ��벻Ҫ�ظ�����");
				
				resp.sendRedirect(req.getContextPath() + "/login.jsp");
			}
		} catch (Exception e) {
			
			e.printStackTrace();
		}
		
		
		
		
	} 

	
}
