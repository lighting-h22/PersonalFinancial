
package com.namingless.servlet;

import com.namingless.daoImpl.AssetsDaoImpl;

import utils.DaoImplUtil;

public class Test {

	public static void main(String[] args) {
		System.out.println(DaoImplUtil.getDao(AssetsDaoImpl.class));
		
	}
	
}
