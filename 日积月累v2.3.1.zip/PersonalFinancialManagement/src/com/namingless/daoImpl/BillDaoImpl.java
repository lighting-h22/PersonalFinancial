/**
 * 
 */
package com.namingless.daoImpl;

import java.io.IOException;
import java.io.InputStream;
import java.util.List;

import org.apache.ibatis.io.Resources;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;

import com.namingless.dao.BillDao;
import com.namingless.pojo.Bill;
import com.namingless.pojo.User;

/**
 * ��Ŀ�� QDD
 * ����UserDaoImpl
 * ������
 * ������Adimitor
 * ����ʱ��2021��4��14��
 */
public class BillDaoImpl extends BillDao {
	InputStream input = null;
	List<Bill> list = null;
	SqlSession sqlSession = null;
	String resource = "./com/namingless/mapper/mybatis-config.xml";
	private SqlSession getSqlSession(){
		SqlSessionFactory sqlSessionFactory =null;
		try {
			input = Resources.getResourceAsStream(resource);
			sqlSessionFactory = new SqlSessionFactoryBuilder().build(input);
			input.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return sqlSessionFactory.openSession();
	}
	public List<Bill> findBillsByPriceAsc(int u_id){
		sqlSession = getSqlSession();
		list = sqlSession.selectList("com.namingless.mapper.BillMapper.findBillsByPriceAsc",u_id);
	
		try {
			sqlSession.close();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return list;
		
	}
	
	public List<Bill> findBillsByPriceDesc(int u_id){
		sqlSession = getSqlSession();
		list = sqlSession.selectList("com.namingless.mapper.BillMapper.findBillsByPriceDesc",u_id);
	
		try {
			sqlSession.close();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return list;
		
	}
	/**
	 * @param monthValue
	 */
	public double getTotalOfMonth(int monthValue) {
		double result = 0;
		
		return result;
		
	}
	
	
}
