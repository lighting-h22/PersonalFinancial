package com.namingless.services;

import com.namingless.pojo.Income;
import com.namingless.pojo.Pager;

public interface IncomeService {
	public Pager<Income> getIcomeByYear(Income income, int pageNum, int pageSize);

	public Pager<Income> getIcomeByDate(Income income, int pageNum, int pageSize);
	
	public Pager<Income> getIcomeByMon(Income income, int pageNum, int pageSize);
}
