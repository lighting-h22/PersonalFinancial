package com.namingless.services;
import com.namingless.dao.IncomeDao;
import com.namingless.daoImpl.IncomeDaoImpl;
import com.namingless.pojo.Income;
import com.namingless.pojo.Pager;


public class IncomeServiceImpl implements IncomeService{

	private IncomeDao incomeDao;
	public IncomeServiceImpl() {
		incomeDao = new IncomeDaoImpl();
	}
	
	public IncomeDao getIncomeDao() {
		return incomeDao;
	}
	
	public void setIncomeDao(IncomeDao incomeDao) {
		this.incomeDao = incomeDao;
	}
	
	@Override
	public Pager<Income> getIcomeByYear(Income income, int pageNum, int pageSize) {
		Pager<Income> result = incomeDao.getIcomeByYear(income, pageNum, pageSize);
		return result;
	}

	@Override
	public Pager<Income> getIcomeByDate(Income income, int pageNum, int pageSize) {
		Pager<Income> result = incomeDao.getIcomeByDate(income, pageNum, pageSize);
		return result;
	}

	@Override
	public Pager<Income> getIcomeByMon(Income income, int pageNum, int pageSize) {
		Pager<Income> result = incomeDao.getIcomeByMon(income, pageNum, pageSize);
		return result;
	}

}
