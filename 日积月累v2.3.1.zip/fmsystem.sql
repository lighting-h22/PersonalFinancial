/*
 Navicat MySQL Data Transfer

 Source Server         : 123456：my
 Source Server Type    : MySQL
 Source Server Version : 100414
 Source Host           : 127.0.0.1:3306
 Source Schema         : fmsystem

 Target Server Type    : MySQL
 Target Server Version : 100414
 File Encoding         : 65001

 Date: 14/06/2021 00:35:56
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for assets
-- ----------------------------
DROP TABLE IF EXISTS `assets`;
CREATE TABLE `assets`  (
  `a_id` bigint NOT NULL AUTO_INCREMENT,
  `u_id` bigint NULL DEFAULT NULL,
  `a_virtual` double NULL DEFAULT 0,
  `a_entity` double NULL DEFAULT 0,
  PRIMARY KEY (`a_id`) USING BTREE,
  INDEX `fk_a_uid`(`u_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 19 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of assets
-- ----------------------------
INSERT INTO `assets` VALUES (1, 1, 600, 500);
INSERT INTO `assets` VALUES (2, 2, 45, 88);
INSERT INTO `assets` VALUES (5, 6, 8, 8);
INSERT INTO `assets` VALUES (16, NULL, 1, 0);
INSERT INTO `assets` VALUES (17, NULL, 1, 0);
INSERT INTO `assets` VALUES (18, NULL, 1, 0);

-- ----------------------------
-- Table structure for bill
-- ----------------------------
DROP TABLE IF EXISTS `bill`;
CREATE TABLE `bill`  (
  `b_id` bigint NOT NULL AUTO_INCREMENT,
  `u_id` bigint NULL DEFAULT NULL,
  `b_datetime` datetime(0) NULL DEFAULT current_timestamp(0),
  `b_type` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `b_price` double NULL DEFAULT 0,
  `b_note` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  PRIMARY KEY (`b_id`) USING BTREE,
  INDEX `fk_b_uid`(`u_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 131 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of bill
-- ----------------------------
INSERT INTO `bill` VALUES (10, 1, '2021-05-28 13:59:39', '旅游', 666, NULL);
INSERT INTO `bill` VALUES (11, 1, '2021-05-28 13:59:32', '旅游', 666, NULL);
INSERT INTO `bill` VALUES (12, 1, '2021-05-28 13:59:33', '通讯', 888, NULL);
INSERT INTO `bill` VALUES (103, 1, '2021-05-28 13:59:32', '通讯', 50, NULL);
INSERT INTO `bill` VALUES (108, 1, '2021-06-02 19:14:39', '餐饮', 12, NULL);
INSERT INTO `bill` VALUES (112, 1, '2021-01-01 10:51:02', '餐饮', 13, '1');
INSERT INTO `bill` VALUES (113, 1, '2021-01-01 11:57:47', '餐饮', 18, '1');
INSERT INTO `bill` VALUES (114, 1, '2021-05-28 13:59:32', '通讯', 23, NULL);
INSERT INTO `bill` VALUES (115, 1, '2021-06-02 19:14:39', '餐饮', 28, NULL);
INSERT INTO `bill` VALUES (116, 1, '2021-01-01 10:51:02', '餐饮', 17, NULL);
INSERT INTO `bill` VALUES (117, 1, '2021-01-01 11:57:47', '餐饮', 18, NULL);
INSERT INTO `bill` VALUES (118, 1, '2021-05-28 13:59:32', '通讯', 19, NULL);
INSERT INTO `bill` VALUES (119, 1, '2021-06-02 19:14:39', '餐饮', 20, NULL);
INSERT INTO `bill` VALUES (120, 1, '2021-01-01 10:51:02', '餐饮', 21, NULL);
INSERT INTO `bill` VALUES (121, 1, '2021-01-01 11:57:47', '餐饮', 22, NULL);
INSERT INTO `bill` VALUES (122, 1, '2021-01-02 11:57:47', '餐饮', 23, NULL);
INSERT INTO `bill` VALUES (123, 1, '2021-01-03 11:57:47', '餐饮', 24, NULL);
INSERT INTO `bill` VALUES (124, 1, '2021-01-04 11:57:47', '餐饮', 25, NULL);
INSERT INTO `bill` VALUES (125, 1, '2021-01-05 11:57:47', '餐饮', 26, NULL);
INSERT INTO `bill` VALUES (126, 1, '2021-05-28 13:59:32', '旅游', 666, NULL);
INSERT INTO `bill` VALUES (127, 1, '2021-05-29 13:59:32', '旅游', 667, NULL);
INSERT INTO `bill` VALUES (128, 1, '2021-05-30 13:59:32', '旅游', 668, NULL);
INSERT INTO `bill` VALUES (129, 1, '2021-05-31 13:59:32', '旅游', 669, NULL);
INSERT INTO `bill` VALUES (130, 1, '2021-06-01 13:59:32', '旅游', 670, NULL);

-- ----------------------------
-- Table structure for income
-- ----------------------------
DROP TABLE IF EXISTS `income`;
CREATE TABLE `income`  (
  `i_id` bigint NOT NULL AUTO_INCREMENT,
  `u_id` bigint NULL DEFAULT NULL,
  `i_date` date NULL DEFAULT current_timestamp,
  `i_addition` double NULL DEFAULT NULL,
  PRIMARY KEY (`i_id`) USING BTREE,
  INDEX `fk_i_uid`(`u_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 22 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of income
-- ----------------------------
INSERT INTO `income` VALUES (1, 1, '2021-01-01', 12);
INSERT INTO `income` VALUES (2, 1, '2021-01-01', 56);
INSERT INTO `income` VALUES (3, 1, '2021-06-02', 500);
INSERT INTO `income` VALUES (4, 1, '2021-01-01', 400);
INSERT INTO `income` VALUES (5, 1, '2021-01-01', 10);
INSERT INTO `income` VALUES (6, 1, '2021-06-02', 11);
INSERT INTO `income` VALUES (7, 1, '2021-01-01', 300);
INSERT INTO `income` VALUES (8, 1, '2021-01-01', 25);
INSERT INTO `income` VALUES (9, 1, '2021-06-02', 35);
INSERT INTO `income` VALUES (10, 1, '2021-01-01', 65);
INSERT INTO `income` VALUES (11, 1, '2021-01-17', 95);
INSERT INTO `income` VALUES (12, 1, '2021-06-02', 125);
INSERT INTO `income` VALUES (13, 1, '2021-01-01', 11);
INSERT INTO `income` VALUES (14, 1, '2021-01-03', 185);
INSERT INTO `income` VALUES (15, 1, '2021-06-02', 359);
INSERT INTO `income` VALUES (16, 1, '2021-01-04', 915);
INSERT INTO `income` VALUES (17, 1, '2021-01-01', 533);
INSERT INTO `income` VALUES (18, 1, '2021-06-02', 151);
INSERT INTO `income` VALUES (19, 1, '2021-01-08', 152);
INSERT INTO `income` VALUES (20, 1, '2021-01-09', 153);
INSERT INTO `income` VALUES (21, 1, '2021-01-02', 152);

-- ----------------------------
-- Table structure for manager
-- ----------------------------
DROP TABLE IF EXISTS `manager`;
CREATE TABLE `manager`  (
  `m_id` int NOT NULL AUTO_INCREMENT,
  `m_pw` char(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `m_name` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  PRIMARY KEY (`m_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of manager
-- ----------------------------

-- ----------------------------
-- Table structure for user
-- ----------------------------
DROP TABLE IF EXISTS `user`;
CREATE TABLE `user`  (
  `u_id` bigint NOT NULL AUTO_INCREMENT,
  `u_pw` char(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `u_name` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `u_budget` double NULL DEFAULT NULL,
  `a_id` bigint NULL DEFAULT NULL,
  PRIMARY KEY (`u_id`) USING BTREE,
  INDEX `fk_u_aid`(`a_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 43 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci COMMENT = '用户' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of user
-- ----------------------------
INSERT INTO `user` VALUES (1, '1', '1', 500, 1);

-- ----------------------------
-- View structure for months_outcome
-- ----------------------------
DROP VIEW IF EXISTS `months_outcome`;
CREATE ALGORITHM = UNDEFINED SQL SECURITY DEFINER VIEW `months_outcome` AS SELECT 
        `fmsystem`.`bill`.`b_id` AS `b_id`,
        SUM(`fmsystem`.`bill`.`b_price`) AS `sum`,
        CONCAT(YEAR(`fmsystem`.`bill`.`b_datetime`),
                '-',
                MONTH(`fmsystem`.`bill`.`b_datetime`)) AS `months`
    FROM
        `fmsystem`.`bill`
    GROUP BY CONCAT(YEAR(`fmsystem`.`bill`.`b_datetime`),
            '-',
            MONTH(`fmsystem`.`bill`.`b_datetime`)) ;

-- ----------------------------
-- View structure for weeks_outcome
-- ----------------------------
DROP VIEW IF EXISTS `weeks_outcome`;
CREATE ALGORITHM = UNDEFINED SQL SECURITY DEFINER VIEW `weeks_outcome` AS SELECT 
        `fmsystem`.`bill`.`b_id` AS `b_id`,
        SUM(`fmsystem`.`bill`.`b_price`) AS `sum`,
        CONCAT(YEAR(`fmsystem`.`bill`.`b_datetime`),
                '-',
                week(`fmsystem`.`bill`.`b_datetime`)) AS `weeks`
    FROM
        `fmsystem`.`bill`
    GROUP BY CONCAT(YEAR(`fmsystem`.`bill`.`b_datetime`),
                '-',
                week(`fmsystem`.`bill`.`b_datetime`)) ;

-- ----------------------------
-- View structure for year_outcome
-- ----------------------------
DROP VIEW IF EXISTS `year_outcome`;
CREATE ALGORITHM = UNDEFINED SQL SECURITY DEFINER VIEW `year_outcome` AS SELECT 
        `fmsystem`.`bill`.`b_id` AS `b_id`,
        SUM(`fmsystem`.`bill`.`b_price`) AS `sum`,
        YEAR(`fmsystem`.`bill`.`b_datetime`)
                 AS `years`
    FROM
        `fmsystem`.`bill`
    GROUP BY YEAR(`fmsystem`.`bill`.`b_datetime`) ;

SET FOREIGN_KEY_CHECKS = 1;
